import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { CheckCircle2, XCircle, Percent, Calculator } from "lucide-react";
import spiderManLogo from '@assets/generated_images/minimalist_spider-man_logo_icon.png';

export default function AttendanceCalculator() {
  const [percentage, setPercentage] = useState(75);
  const [present, setPresent] = useState<string>("");
  const [total, setTotal] = useState<string>("");
  const [result, setResult] = useState<React.ReactNode>(null);
  const [isBunking, setIsBunking] = useState<boolean | null>(null);

  const calculate = () => {
    const p = parseInt(present);
    const t = parseInt(total);
    const requiredPct = percentage;

    if (isNaN(p) || isNaN(t) || isNaN(requiredPct)) {
      setResult("Please enter valid numbers ¯\\_(ツ)_/¯");
      setIsBunking(null);
      return;
    }

    if (p < 0 || t <= 0 || p > t) {
      setResult("Invalid input values. Present cannot be greater than total.");
      setIsBunking(null);
      return;
    }

    if (p / t >= requiredPct / 100) {
      const daysAvailableToBunk = Math.floor(
        (100 * p - requiredPct * t) / requiredPct
      );
      
      const currentPct = ((p / t) * 100).toFixed(2);
      const newTotal = daysAvailableToBunk + t;
      const newPct = ((p / newTotal) * 100).toFixed(2);

      setIsBunking(true);
      setResult(
        <div className="space-y-4">
          <div className="text-emerald-400 font-bold text-xl flex items-center justify-center gap-2">
            <CheckCircle2 className="w-6 h-6" />
            You can bunk for {daysAvailableToBunk} more days!
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-emerald-900/20 p-3 rounded-lg border border-emerald-900/50">
              <div className="text-xs text-emerald-300/70 uppercase tracking-wider font-bold mb-1">Current</div>
              <div className="text-2xl font-mono text-emerald-100">{currentPct}%</div>
              <div className="text-xs text-emerald-400/50 font-mono">{p}/{t}</div>
            </div>
            <div className="bg-emerald-900/20 p-3 rounded-lg border border-emerald-900/50">
              <div className="text-xs text-emerald-300/70 uppercase tracking-wider font-bold mb-1">After Bunking</div>
              <div className="text-2xl font-mono text-emerald-100">{newPct}%</div>
              <div className="text-xs text-emerald-400/50 font-mono">{p}/{newTotal}</div>
            </div>
          </div>
        </div>
      );
    } else {
      const attendanceNeeded = Math.ceil(
        (requiredPct * t - 100 * p) / (100 - requiredPct)
      );
      
      const currentPct = ((p / t) * 100).toFixed(2);
      const newPresent = attendanceNeeded + p;
      const newTotal = attendanceNeeded + t;
      const newPct = ((newPresent / newTotal) * 100).toFixed(2);

      setIsBunking(false);
      setResult(
        <div className="space-y-4">
          <div className="text-rose-400 font-bold text-xl flex items-center justify-center gap-2">
            <XCircle className="w-6 h-6" />
            Attend {attendanceNeeded} more classes!
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-rose-900/20 p-3 rounded-lg border border-rose-900/50">
              <div className="text-xs text-rose-300/70 uppercase tracking-wider font-bold mb-1">Current</div>
              <div className="text-2xl font-mono text-rose-100">{currentPct}%</div>
              <div className="text-xs text-rose-400/50 font-mono">{p}/{t}</div>
            </div>
            <div className="bg-rose-900/20 p-3 rounded-lg border border-rose-900/50">
              <div className="text-xs text-rose-300/70 uppercase tracking-wider font-bold mb-1">After Attending</div>
              <div className="text-2xl font-mono text-rose-100">{newPct}%</div>
              <div className="text-xs text-rose-400/50 font-mono">{newPresent}/{newTotal}</div>
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen w-full bg-background text-foreground overflow-hidden relative flex flex-col items-center justify-center p-4">
      {/* Abstract Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-purple-600/20 blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-10"
      >
        <Card className="backdrop-blur-xl bg-card/40 border-white/10 shadow-2xl">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto bg-primary/20 p-3 rounded-full w-fit mb-2 border border-primary/30">
              <img 
                src={spiderManLogo} 
                alt="Spider-Man Logo" 
                className="w-10 h-10 object-contain" 
              />
            </div>
            <CardTitle className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60 tracking-tight">
              75 Attendance
            </CardTitle>
            <CardDescription className="text-muted-foreground flex items-center justify-center gap-2">
              Calculate your bunking potential
              <span className="inline-block w-1 h-1 rounded-full bg-muted-foreground/50" />
              <span className="text-xs font-medium text-primary/80 uppercase tracking-widest">Owner: UDAY D</span>
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6 pt-6">
            <div className="space-y-2">
              <Label htmlFor="percentage" className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1">Target Percentage</Label>
              <div className="relative">
                <Select 
                  value={percentage.toString()} 
                  onValueChange={(val) => setPercentage(parseInt(val))}
                >
                  <SelectTrigger className="bg-secondary/50 border-white/5 h-12 text-lg backdrop-blur-sm focus:ring-primary/50 transition-all hover:bg-secondary/70">
                    <SelectValue placeholder="Select percentage" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-white/10">
                    {[60, 65, 70, 75, 80, 85, 90].map((pct) => (
                      <SelectItem key={pct} value={pct.toString()} className="focus:bg-primary/20">
                        {pct}%
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Percent className="absolute right-10 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none opacity-50" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="present" className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1">Present</Label>
                <Input
                  id="present"
                  type="number"
                  placeholder="0"
                  value={present}
                  onChange={(e) => setPresent(e.target.value)}
                  className="bg-secondary/50 border-white/5 h-12 text-lg font-mono backdrop-blur-sm focus:ring-primary/50 transition-all hover:bg-secondary/70"
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="total" className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1">Total</Label>
                <Input
                  id="total"
                  type="number"
                  placeholder="0"
                  value={total}
                  onChange={(e) => setTotal(e.target.value)}
                  className="bg-secondary/50 border-white/5 h-12 text-lg font-mono backdrop-blur-sm focus:ring-primary/50 transition-all hover:bg-secondary/70"
                  min="0"
                />
              </div>
            </div>

            <Button 
              onClick={calculate}
              className="w-full h-12 text-lg font-bold bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 shadow-lg shadow-primary/20 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
            >
              <Calculator className="w-5 h-5 mr-2" />
              Calculate
            </Button>

            <AnimatePresence mode="wait">
              {result && (
                <motion.div
                  key={isBunking === null ? "error" : isBunking ? "bunk" : "attend"}
                  initial={{ opacity: 0, height: 0, scale: 0.95 }}
                  animate={{ opacity: 1, height: "auto", scale: 1 }}
                  exit={{ opacity: 0, height: 0, scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 200, damping: 20 }}
                  className="overflow-hidden"
                >
                  <Separator className="my-4 bg-white/5" />
                  <div className="bg-secondary/30 rounded-xl p-6 border border-white/5 backdrop-blur-md">
                    {result}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center text-sm text-muted-foreground/40 font-medium tracking-widest uppercase space-y-2">
          <div>75Attendance • Est 2025</div>
          <div>Owner: UDAY D</div>
        </div>
      </motion.div>
    </div>
  );
}
